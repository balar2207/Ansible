Master/Controller node:

#ssh-keygen

#ssh-copy-id user@linux-client-ip

Staging Changes
###git add <filename>

Committing With Staging
###git commit -m "Your commit message"


Committing Without Staging
###git commit -am "Your commit message"

###git push

