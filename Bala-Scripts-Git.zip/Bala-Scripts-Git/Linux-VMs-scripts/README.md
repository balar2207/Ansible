Notes:
1) -bash: ./sysprep.sh: /bin/bash^M: bad interpreter: No such file or directory: "sed -i 's/\r$//' sysprep.sh"
